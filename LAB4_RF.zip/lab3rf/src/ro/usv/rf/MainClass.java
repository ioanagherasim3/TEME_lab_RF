package ro.usv.rf;

public class MainClass {
	
	
	public static void main(String[] args) {
		double[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("D:\\Student\\lab3rf\\in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			/*for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateEuclidianDistance(learningSet[0], learningSet[i]));
			}
			for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateCebisevDistance(learningSet[0], learningSet[i]));
			}
			for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateMahalanobisDistance(learningSet[0], learningSet[i],numberOfPatterns));
			}
			for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateCityBlockDistance(learningSet[0], learningSet[i]));
			}*/
			double [][]m=new double [learningSet.length][learningSet.length];
				 m=DistanceUtils.calculateEuclidianDistanceMatrice(learningSet);
				 for(int i=0;i<learningSet.length;i++)
					{
						for (int j=0;j<learningSet.length;j++)
						{
							System.out.print(m[i][j]+"  ");
						} 
						System.out.print("\n");
					}	
			
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}
