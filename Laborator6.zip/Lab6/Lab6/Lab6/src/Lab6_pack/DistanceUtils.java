package Lab6_pack;
import Lab6_pack.MainClass;

public class DistanceUtils {

	
	protected static double calculateEuclidianDistance(double learningSet, double grade) {
		
		return Math.round((Math.sqrt(Math.pow(learningSet-grade,2))) * 100.0) / 100.0;
	}
	
	
	public static double calculateEuclidianDistance2(double firstLine, String nextLine[], int numberOfFeatures) {

		double euclidianDistance = 0.0;
		for (int i = 0; i < numberOfFeatures - 1; i++) {
			euclidianDistance += Math.pow(firstLine - Double.valueOf(nextLine[i]), 2);
		}
		
		return Math.round(Math.sqrt(euclidianDistance) * 100.0) / 100.0;
	}
	
	protected static double calculateEuclidianDistance3(double learningSet, double grade) {
		
		return Math.round((Math.sqrt(Math.pow(learningSet-grade,2))) * 100.0) / 100.0;
	}
	

}
