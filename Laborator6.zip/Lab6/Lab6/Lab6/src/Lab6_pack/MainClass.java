package Lab6_pack;

import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MainClass {
	
	
	public static void main(String[] args) {
		String[][] learningSet;
		double [] grade=new double[]{3.80, 5.75,6.25, 7.25, 8.5};
		int count=0;
		String []gradevector;
		int []knn= new int[]{1,3,5,7,9,13,17};
		try {
			learningSet = FileUtils.readLearningSetFromFile("C:\\Users\\ioana\\OneDrive\\Desktop\\rf\\Lab6\\Lab6\\Lab6\\in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			double[] newPatterns= initNewPatterns();	
			double distanceMatrix[][] = new double[newPatterns.length][learningSet.length];
			
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
				
			
			/*for(int i=0;i<numberOfPatterns;i++)
			{
				System.out.println(String.format("Nota %s Calificativ %s",learningSet[i][0],learningSet[i][1]));
			}
			*/
			
			for (int i = 0; i < newPatterns.length; i++) {
				for (int j = 0; j < numberOfPatterns; j++) {
					distanceMatrix[i][j] = DistanceUtils.calculateEuclidianDistance2(newPatterns[i], learningSet[j], numberOfFeatures);
					System.out.println(distanceMatrix[i][j]);
				}

				System.out.print("\n");
			}
		/*	
			TreeMap<Double, String> trmap = new TreeMap<Double, String>();
			for (int i = 0; i < newPatterns.length; i++) {
				for (int j = 0; j < learningSet.length; j++) {
				
					System.out.println(trmap.put(DistanceUtils.calculateEuclidianDistance3(Double.valueOf(learningSet[j][0]), newPatterns[i]),learningSet[j][0]));  //pune distanta in treemap
					}
				
				System.out.print("\n");
				}
			
			*/
			/*for(int i=0;i<numberOfPatterns;i++)
			{
				System.out.println(String.format("Nota %s Calificativ %s",learningSet[i][0],learningSet[i][1]));
			}*/
		
		/*
			for(int k:knn)
			{
			TreeMap<Double,String> treemap=new TreeMap<Double,String>();
			
			for(int i=0;i<grade.length;i++){
				count=0;
				for(int j=0;j<learningSet.length;j++)
				{
					treemap.put(DistanceUtils.calculateEuclidianDistance3(Double.valueOf(learningSet[j][0]), grade[i]),learningSet[j][1]); //pune distanta in treemap
				}
				
				gradevector=new String[k];
				for(Map.Entry<Double,String> entry :treemap.entrySet())
				{
					if(count<k)
					{
						gradevector[count]=entry.getValue();
						count++;
					}
				}
				Map<String,Long> freq=
						Stream.of(gradevector).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
				//System.out.println(freq);
				//System.out.println(String.format("%s-nn->grade=%s->%s",k,grade[i],freq));
				
				double noOfOccurance=0.0;
				String result=" ";
				for(Map.Entry<String,Long> entry :freq.entrySet())
				{
					if(entry.getValue()>noOfOccurance)
					{
						noOfOccurance=entry.getValue();
						result=entry.getKey();
					}
				}
				
				System.out.println(String.format("%s-nn->grade=%s->%s",k,grade[i],result));
				
			}
			}
			*/
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}
		
		public static double[] initNewPatterns() {
			double[] newPatterns = new double[5];
			newPatterns[0] = 3.80;
			newPatterns[1] = 5.75;
			newPatterns[2] = 6.25;
			newPatterns[3] = 7.25;
			newPatterns[4] = 8.5;			
			return newPatterns;
		
		}

}
