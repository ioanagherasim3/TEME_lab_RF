package Lab6_pack;

public class USVInputFileCustomException extends Exception {

    public USVInputFileCustomException(String message) {
        super(message);
    }

}