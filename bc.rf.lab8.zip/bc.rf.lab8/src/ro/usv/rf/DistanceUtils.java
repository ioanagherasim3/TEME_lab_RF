package ro.usv.rf;

public class DistanceUtils {
	protected static double calculateSimpleEuclidianDistance(double[] pattern1, String[] pattern2) {
		double distance = 0.0;
		double sum = 0.0;
		for (int  feature = 0; feature < pattern1.length; feature++) {
			distance += Math.pow((pattern1[feature]- Double.valueOf(pattern2[feature])), 2);
		}
		return Math.sqrt(distance);
	}
	
}
