package ro.usv.rf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


public class MainClass {

	public static void main(String[] args) {
		String[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("iris.csv");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length-1;
		//	double min = DistanceUtils.calculateSimpleEuclidianDistance(learningSet[0], learningSet[1]);
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			
			double[][] newPatterns = initNewPatterns();

			double[][] distances = new double[newPatterns.length][numberOfPatterns];

			for(int i=0; i<newPatterns.length; i++) 
				for(int j=0; j<numberOfPatterns; j++)
				{
					distances[i][j] = DistanceUtils.calculateSimpleEuclidianDistance(newPatterns[i], learningSet[j]);
					System.out.println(String.format("Distance between %s and %s is: %s",i,j, distances[i][j]));
				}
			
			
			Map<String, Integer> classesMap = new HashMap<String, Integer>();
			
			//create map with distinct classes and number of occurence for each class
			for (int i=0; i<numberOfPatterns; i++)
			{
				String clazz = learningSet[i][learningSet[i].length-1];
				if (classesMap.containsKey(clazz))
				{
					Integer nrOfClassPatterns = classesMap.get(clazz);
					classesMap.put(clazz, nrOfClassPatterns + 1);
				}
				else
				{
					classesMap.put(clazz, 1);
				}
			}
			System.out.println(String.format(" Avem %s", classesMap));
			
			Random random = new Random();
			//map that keeps for each class the random patterns selected for evaluation set
			Map<String, List<Integer>> classesEvaluationPatterns = new HashMap<String, List<Integer>>();
			Integer evaluationSetSize = 0;
			for (Map.Entry<String, Integer> entry: classesMap.entrySet())
			{
				String className = entry.getKey(); // scoate denumirele 
				Integer classMembers = entry.getValue();// scoate valorile 
				Integer evaluationPatternsNr = Math.round(classMembers *10/100); //rezultatul cu o floare 
				evaluationSetSize += evaluationPatternsNr; // aduna toate rezultatele 
				List<Integer> selectedPatternsForEvaluation = new ArrayList<Integer>();
				for (int i=0; i<evaluationPatternsNr; i++) // repeta de 10%
				{
					Integer patternNr = random.nextInt(classMembers ) +1;// extrage random din alea cu acelasi nume? , aduna +1 la valoare extrasa pt  ?
					while (selectedPatternsForEvaluation.contains(patternNr))
					{
						patternNr = random.nextInt(classMembers ) +1;
					}
					selectedPatternsForEvaluation.add(patternNr); //adauga 
				}
				classesEvaluationPatterns.put(className, selectedPatternsForEvaluation);				
			}
			
			String[][] evaluationSet = new String[evaluationSetSize][numberOfPatterns];
			String[][] trainingSet = new String[numberOfPatterns-evaluationSetSize][numberOfPatterns];
			int evaluationSetIndex = 0;
			int trainingSetIndex = 0;
			Map<String, Integer> classCurrentIndex = new HashMap<String, Integer>();
			for (int i=0; i<numberOfPatterns; i++)
			{
				String className = learningSet[i][numberOfFeatures];
				if (classCurrentIndex.containsKey(className))
				{
					int currentIndex = classCurrentIndex.get(className);
					classCurrentIndex.put(className, currentIndex+1);
				}
				else
				{
					classCurrentIndex.put(className, 1);
				}
				if (classesEvaluationPatterns.get(className).contains(classCurrentIndex.get(className)))
				{
					evaluationSet[evaluationSetIndex] = learningSet[i];
					evaluationSetIndex++;
				}
				else
				{
					trainingSet[trainingSetIndex] = learningSet[i];
					trainingSetIndex++;
				}
			}
			
			Map<String, Integer> classesList = new HashMap<String, Integer>();
			System.out.println("Number of distinct classes: " + classesList.size());
			double[][] Matrix = new double[classesList.size()][numberOfFeatures + 1];

			for (int i = 0; i < Matrix.length; i++) {
				double freeTermSum = 0.0;
				for (int j = 0; j < Matrix[0].length - 1; j++) {
					double totalSum = 0.0;
					int totalElements = 0;

					for (int k = 0; k < learningSet.length; k++) {
						if (learningSet[k][numberOfFeatures].equals(classesList.get(i))) {
							totalSum += Double.valueOf(learningSet[k][j]);
							totalElements++;
						}
					}
					Matrix[i][j] = totalSum / totalElements;
					freeTermSum += Math.pow(Matrix[i][j], 2);

				}
				Matrix[i][Matrix[0].length - 1] = -0.5 * freeTermSum;
			}
			for (int i = 0; i < Matrix.length; i++) {
				for (int j = 0; j < Matrix[0].length; j++) {
					System.out.print(Matrix[i][j] + " ");
				}
				System.out.println();
			}
			
			//FileUtils.writeLearningSetToFile("eval.txt", evaluationSet);
			//FileUtils.writeLearningSetToFile("train.txt", trainingSet);
			
		} catch (USVInputFileCustomException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Finished learning set operations");
		}
	}
	private static double[][] initNewPatterns() {
		double[][] newPatterns = new double[3][2];
		newPatterns[0][0] = 25.89;
		newPatterns[0][0] = 47.56;
		newPatterns[0][0] = 24;
		newPatterns[0][0] = 45.15;
		newPatterns[0][0] = 25.33;
		newPatterns[0][0] = 45.44;

		return newPatterns;
	}

}
