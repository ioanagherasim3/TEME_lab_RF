package ro.usv.rf;

public class DistanceUtils {

	public static double calculateEuclidianDistance(double[] x, double[] y)
	{
		double edistance=0.0;
		for(int i=0;i<2;i++)
		{
			edistance +=Math.pow((x[i]-y[i]),2);
		}
		return Math.sqrt(edistance);
	}
	public static double calculateMahalanobisDistance(double[] x, double[] y, int nrOfPatterns)
	{
		double mdistance=0.0;
		
	
		for(int i=0; i<x.length; i++) 
		 {
			 mdistance +=Math.pow(x[i]-y[i],nrOfPatterns);
			 
			 
		 }
		return Math.pow(mdistance,(double)1/nrOfPatterns);
	}
	public static double calculateCebisevDistance(double[] x, double[] y)
	{
		double cdistance=0.0;
		
		for(int i=0;i<x.length;i++)
		{
			double currentDistance=Math.abs(x[i]-y[i]);
			if(currentDistance>cdistance)
			{
				cdistance=currentDistance;
			}
		}
		
		return cdistance;
	}
	public static double calculateCityBlockDistance(double[] x, double[] y)
	{
		double cbdistance=0.0;
		
		for(int i=0;i<x.length;i++)
		{
			cbdistance +=Math.abs(x[i]-y[i]);
		}
		
		return cbdistance;
	}
	
}
