package ro.usv.rf;

public class DistanceUtils {
	protected static double calculateSimpleEuclidianDistance(String[] learningSet, String[] learningSet2) {
		double distance = 0.0;
		for (int feature = 0; feature < learningSet.length-1; feature++) {
			distance += Math.pow((Double.valueOf (learningSet[feature]) - Double.valueOf (learningSet2[feature])), 2);
		}
		return Math.floor(Math.sqrt(distance) * 100) / 100;
	}
	
	protected static double calculateSimpleCebisevDistance(double[] pattern1, double pattern2[]) {
		double distance = 0.0;
		for (int feature = 0; feature < pattern1.length; feature++) {
			double currentDistance = Math.abs(pattern1[feature] - pattern2[feature]);
			distance = (currentDistance > distance) ? currentDistance : distance;
		}
		return distance;
	}
	
	protected static double calculateSimpleCityDistance(double[] pattern1, double pattern2[]) {
		double distance = 0.0;
		for (int feature = 0; feature < pattern1.length; feature++) {
			double currentValue = Math.abs(pattern1[feature] - pattern2[feature]);
			distance += currentValue;
		}
		return distance;
	}
	
	protected static double calculateSimpleMahalanobisDistance(double[] pattern1, double pattern2[], int nrOfPatterns) {
		double distance = 0.0;
		for (int feature = 0; feature < pattern1.length; feature++) {
			distance += Math.pow((pattern1[feature] - pattern2[feature]), nrOfPatterns);
		}
		return Math.pow(distance, (double)1/nrOfPatterns);
	}
	
	protected static String[][] calculateDistanceMatrix(String[][] learningSet) {
		int numberOfPatterns = learningSet.length;
		String[][] distanceMatrix = new String[numberOfPatterns][numberOfPatterns];
		for (int line = 0; line < numberOfPatterns; line++) {
			for (int column = line + 1; column < numberOfPatterns; column++) {
				//distanceMatrix[line][column] = calculateSimpleEuclidianDistance(learningSet[line],learningSet[column]);
				distanceMatrix[column][line] = distanceMatrix[line][column];
			}
		}
		
		for (int line = 0; line < learningSet.length; line++) {
			for (int column = 0; column < learningSet.length; column++) {
				System.out.print(distanceMatrix[line][column] + " ");
			}
			System.out.println();
		}
		return distanceMatrix;
	}
}
