package ro.usv.rf;


public class MainClass {
	
	
	public static void[][] main(String[] args) {
		String[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("data.csv");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			double[][] newPatterns = initNewPatterns();
			double[][]distances = new double[newPatterns.length][numberOfPatterns];
			/*for(int i=0;i<newPatterns.length;i++)
				for(int j=0;j<numberOfPatterns;j++) {
					distances[i][j]=DistanceUtils.calculateSimpleEuclidianDistance(newPatterns[i], learningSet[j]);
				}
			*/
			for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateSimpleEuclidianDistance(learningSet[0], learningSet[i]));
			}
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			for (int patternNumber = 1; patternNumber < numberOfPatterns; patternNumber++) {
				//double euclidianDistance = DistanceUtils.calculateSimpleEuclidianDistance(learningSet[0], learningSet[patternNumber]);
				//System.out.println("The euclidian distance between first pattern and pattern " + patternNumber + " is: " + euclidianDistance);
				//double cebisevDistance = DistanceUtils.calculateSimpleCebisevDistance(learningSet[0], learningSet[patternNumber]);
				//System.out.println("The cebisev distance between first pattern and pattern " + patternNumber + " is: " + cebisevDistance);
				//double cityDistance = DistanceUtils.calculateSimpleCityDistance(learningSet[0], learningSet[patternNumber]);
				//System.out.println("The city distance between first pattern and pattern " + patternNumber + " is: " + cityDistance);
				//double mahalanobisDistance = DistanceUtils.calculateSimpleMahalanobisDistance(learningSet[0], learningSet[patternNumber], numberOfPatterns);
				//System.out.println("The mahalanobis distance between first pattern and pattern " + patternNumber + " is: " + mahalanobisDistance);
				
			}
			//double[][] distanceMatrix = DistanceUtils.calculateDistanceMatrix(learningSet);
			//int searchPattern = numberOfPatterns-1;
			//int closesPattern= 0;
			//double [] distanceRow=distanceMatrix[searchPattern];
			//double minDistance = distanceRow[0];
			//for(int i=0;i<distanceRow.length;i++)
			//{
				//if(distanceRow[i]< minDistance && i!=searchPattern)
				//{
					//minDistance=distanceRow[i];
					//closesPattern=i;
				//}
			//}
			//System.out.println(String.format("Closes pattern is %s",closesPattern));
			//int classColumn=learningSet[closesPattern].length - 1;
			//System.out.println(String.format("Searched class %s",learningSet[closesPattern][classColumn]));
			
			
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
		
	}

	private static double[][] initNewPatterns(){
		double[][] newPatterns=new double[3][2];
		newPatterns[0][0]=25.89;
		newPatterns[0][1]=47.56;
		newPatterns[1][0]=24;
		newPatterns[1][1]=45.15;
		newPatterns[2][0]=25.33;
		newPatterns[2][1]=45.44;
		return newPatterns;
	}

}
