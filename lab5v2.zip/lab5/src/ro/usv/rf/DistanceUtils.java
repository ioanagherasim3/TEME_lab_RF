package ro.usv.rf;

public class DistanceUtils {

	public static double calculateEuclidianDistance(String[] learningSet1,String[] learningSet2)
	{
		double edistance=0.0;
		for(int i=0;i<learningSet1.length;i++)
		{
			edistance+=Math.pow(Double.parseDouble(learningSet1[i])-Double.parseDouble(learningSet2[i]), 2);
		}
		return Math.sqrt(edistance);
		
	}
	/*public static double calculateEuclidianDistance(double[] x, double[] y, int n)
	{
		double edistance=0.0;
		for(int i=0;i<n;i++)
		{
			edistance +=Math.pow((x[i]-y[i]),2);
		}
		return Math.sqrt(edistance);
	}
	
	public class DistanceUtils {
	protected static double calculateSimpleEuclidianDistance(String[] learningSet, String[] learningSet2) {
		double distance = 0.0;
		for (int feature = 0; feature < learningSet.length-1; feature++) {
			distance += Math.pow((Double.valueOf (learningSet[feature]) - Double.valueOf (learningSet2[feature])), 2);
		}
		return Math.floor(Math.sqrt(distance) * 100) / 100;
	}
	
	*/
	public static double calculateMahalanobisDistance(double[] x, double[] y, int nrOfPatterns)
	{
		double mdistance=0.0;
		
	
		for(int i=0; i<x.length; i++) 
		 {
			 mdistance +=Math.pow(x[i]-y[i],nrOfPatterns);
			 
			 
		 }
		return Math.pow(mdistance,(double)1/nrOfPatterns);
	}
	public static double calculateCebisevDistance(double[] x, double[] y)
	{
		double cdistance=0.0;
		
		for(int i=0;i<x.length;i++)
		{
			double currentDistance=Math.abs(x[i]-y[i]);
			if(currentDistance>cdistance)
			{
				cdistance=currentDistance;
			}
		}
		
		return cdistance;
	}
	public static double calculateCityBlockDistance(double[] x, double[] y)
	{
		double cbdistance=0.0;
		
		for(int i=0;i<x.length;i++)
		{
			cbdistance +=Math.abs(x[i]-y[i]);
		}
		
		return cbdistance;
	}
	/*public static double [][]calculateEuclidianDistanceMatrice(double [][]learningSet)
	{
		double [][]mat=new double [learningSet.length][learningSet.length];
		
		for(int i=0;i<learningSet.length;i++)
		{
			for(int j=0;j<learningSet.length;j++)
			{
				mat[i][j]=calculateEuclidianDistance(learningSet[i],learningSet[j],learningSet[0].length);
			}
		}
		for(int j=0;j<learningSet.length;j++)
		{
			for(int i=0;i<j;i++)
			{
				mat[j][i]=mat[i][j];
			}
		}
		
		return mat;
	}*/
	public static double calculateEuclidianDistance(double[] ds, String[] learningSet2) {
		double edistance=0.0;
		for(int i=0;i<learningSet1.length;i++)
		{
			edistance+=Math.pow(Double.parseDouble(learningSet1[i])-Double.parseDouble(learningSet2[i]), 2);
		}
		
		return 0;
	}
	
}
