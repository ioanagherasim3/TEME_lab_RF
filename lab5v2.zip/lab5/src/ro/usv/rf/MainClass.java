package ro.usv.rf;

public class MainClass {
	
	
	public static void main(String[] args) {
		String[][] learningSet;
		
		try {
			learningSet = FileUtils.readLearningSetFromFile("D:\\Student\\lab5\\data.csv");
			FileUtils.writeLearningSetToFile("dataout.csv",learningSet);
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			double [][] newPatterns=initNewPatterns();
			double[][] distance=new double[newPatterns.length][numberOfPatterns];
			for(int i=0;i<newPatterns.length;i++)
			{
				for(int j=1; j < numberOfPatterns;j++) 
				{
					distance[i][j]=DistanceUtils.calculateEuclidianDistance(newPatterns[i], learningSet[j]);
				//System.out.println(DistanceUtils.calculateEuclidianDistance(learningSet[0], learningSet[i], numberOfPatterns));
				}
			}
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			
			/*
			 * for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateEuclidianDistance(learningSet[0], learningSet[i], numberOfPatterns));
			}for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateCebisevDistance(learningSet[0], learningSet[i]));
			}
			for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateMahalanobisDistance(learningSet[0], learningSet[i],numberOfPatterns));
			}
			for(int i=1; i < numberOfPatterns;i++) 
			{
				System.out.println(DistanceUtils.calculateCityBlockDistance(learningSet[0], learningSet[i]));
			}*/
			
			/*double [][]m=new double [learningSet.length][learningSet.length];
				 m=DistanceUtils.calculateEuclidianDistanceMatrice(learningSet);
				 for(int i=0;i<learningSet.length;i++)
					{
						for (int j=0;j<learningSet.length;j++)
						{
							System.out.print(m[i][j]+"  ");
						} 
						System.out.print("\n");
					}	*/
		
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

	private static double[][] initNewPatterns(){
				double[][] newPatterns=new double[3][2];
				newPatterns[0][0]=25.89;
				newPatterns[0][1]=47.56;
				newPatterns[1][0]=24;
				newPatterns[1][1]=45.15;
				newPatterns[2][0]=25.33;
				newPatterns[2][1]=45.44;
				return newPatterns;
			}

}
