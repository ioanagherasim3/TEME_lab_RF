package ro.usv.rf;

public class DistanceUtils
{
	protected static double calculateEuclidianDistance(double[] pattern1, double[] pattern2) {
		double distance = 0.0;
		for (int i = 0; i < pattern1.length-1; i++) {
			distance += Math.pow(pattern1[i] - pattern2[i], 2);
		}

		return Math.floor(Math.sqrt(distance));
	}
	protected static double calculateEuclidianDistance(double[] pattern1, String[] pattern2) {
		double distance = 0.0;
		for (int i = 0; i < 2; i++) {
			distance += Math.pow(pattern1[i] - Double.valueOf(pattern2[i]), 2);
		}

		return Math.floor(Math.sqrt(distance));
	}
	
	protected static double[] calculateDistanceMatrix(String[][] learningSet)
	{
		double[][] _newpatterns= MainClass.initNewPatterns();
		int numberOfPatterns = learningSet.length;
		double[] distance = new double[numberOfPatterns];
		for(int j=0; j<3; j++)
		{
		for(int i=0; i<numberOfPatterns; i++)
		{
				distance[i]=calculateEuclidianDistance(_newpatterns[j], learningSet[i]);
		}}
		for(int i=0; i<numberOfPatterns; i++)
		{
			for(int j=0; j<3; j++)
			{
				System.out.print(distance[i]+"  ");
			}
			System.out.println();
		}
		return distance;
	}

	protected static double calculateCebiSevDistance(double[] pattern1, double[] pattern2)
	{
		double distance = 0.0;
		for (int feature = 0; feature < pattern1.length; feature++) {
			double currentValue = Math.abs(pattern1[feature] + pattern2[feature]);
			if (currentValue > distance) {
				distance = currentValue;
			}
		}
		return distance;
	}

	protected static double calculateCityBlockDistance(double[] pattern1, double[] pattern2)
	{
		double distance =0.0;
		for(int feature=0; feature<pattern1.length; feature++)
		{
			double currentValue= Math.abs(pattern1[feature]- pattern2[feature]);
			distance += currentValue;
		}
		return distance;
	}


	protected static double calculateMahalanobis(double[] pattern1, double[] pattern2, int nrOfPattern)
	{
		double distance =0.0;
		for(int feature=0; feature<pattern1.length; feature++)
		{
			distance += Math.pow(pattern1[feature]-pattern2[feature],nrOfPattern);
		}
		return Math.pow(distance, (double)1/nrOfPattern);
	}
}
