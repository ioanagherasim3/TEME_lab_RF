package ro.usv.rf;

import java.util.Arrays;

import ro.usv.rf.DistanceUtils;
import ro.usv.rf.FileUtils;
import ro.usv.rf.USVInputFileCustomException;

public class MainClass {
	
	
	public static void main(String[] args) {
		String[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("C:\\Users\\bagDaca\\Desktop\\Facultate\\Sem2\\RF\\Lab5\\Lab5RF\\data.csv");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			//System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			double[][] newPatterns= initNewPatterns();
			double[][] distances=new double[newPatterns.length][numberOfPatterns];
			
			for(int i=0; i<newPatterns.length; i++)
			{
				for(int j=0;j<numberOfPatterns;j++)
				{
					distances[i][j]=DistanceUtils.calculateEuclidianDistance(newPatterns[i], learningSet[j]);
				}
				//double euclidianDistance=DistanceUtils.calculateEuclidDistance(learningSet[0],learningSet[patternNr]);
				//System.out.println("The euclidian distance between first pattern and pattern "+ patternNr + "is: " +euclidianDistance);
				//double[][] distanceMatrix = DistanceUtils.calculateDistanceMatrix(learningSet);
				/*double cebisevDistance=DistanceUtils.calculateCebiSevDistance(learningSet[0],learningSet[patternNr]);
				System.out.println("The euclidian distance between first pattern and pattern "+ patternNr + "is: " +cebisevDistance);
				double cityDistance=DistanceUtils.calculateCityBlockDistance(learningSet[0],learningSet[patternNr]);
				System.out.println("The euclidian distance between first pattern and pattern "+ patternNr + "is: " +cityDistance);
				double MahalanobisDistance=DistanceUtils.calculateMahalanobis(learningSet[0],learningSet[patternNr], numberOfPatterns);
				System.out.println("The euclidian distance between first pattern and pattern "+ patternNr + "is: " +MahalanobisDistance);*/
			}
			DistanceUtils.calculateDistanceMatrix(learningSet);
			System.out.println(String.format("The learning set has %s patterns and %s features", numberOfPatterns, numberOfFeatures));
		} catch (USVInputFileCustomException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Finished learning set operations");
		}
	}
	public static double[][] initNewPatterns()
	{
		double[][] newPatterns =new double[3][2];
		newPatterns[0][0]=25.89;
		newPatterns[0][1]=47.56;
		newPatterns[1][0]=24;
		newPatterns[1][1]=45.15;
		newPatterns[2][0]=25.33;
		newPatterns[2][1]=45.44;
		return newPatterns;
	}
}
