package lab3;

public class DistanceUtils {
    protected static double calculateEuclidianDistance(double[] linia1, double[] linia2)
    {
        return Math.sqrt( Math.pow(linia1[0] - linia2[1],2) + Math.pow(linia1[1] - linia2[1],2));
    }
    public static double  calculateEuclidianDistance(double p1[],String p2[],int noOfF) {

        double suma=0.0;
        for(int i=0;i<noOfF;i++)
        {
            double r=p1[i]-Double.valueOf(p2[i]);
            r=Math.pow(r,2);
            suma+=r; // sau sum+= Math.pow(p1[i]-Double.valueOf(p2[i]),2);
        }

        return Math.sqrt(suma);
    }

    public static double []calculateEuclidianDistanceMatrice(String [][]learningSet, double[] city)
    {
        double  []mat = new double [learningSet.length];
        for(int i=0;i<learningSet.length;i++)
        {
                mat[i]=calculateEuclidianDistance(city,learningSet[i],2);
        }
        return mat;
    }
  /*  protected static double EuclidianDistanceGEneralisedForm(double[] pattern1, double pattern2[])
    {
        double dist=0.0;
        for(int i=0;i<pattern1.length-1; i++)
            {
               dist += Math.pow((pattern1[i]-pattern2[i]),2);
        }

        return dist;
    }
    protected static double calculateEuclidDistance(double[] pattern1, double[] pattern2) {
        double dist = 0.0;
        for (int i = 0; i < pattern1.length-1; i++) {
            dist += Math.pow(pattern1[i] - pattern2[i], 2);
        }

        return Math.floor(Math.sqrt(dist*10000)/10000);
   }*/
    public static double EuclidianDistanceMatrix (double[] pattern1 ,double pattern2[])
    {
        double  dist=0.0;
        for(int i=0;i<pattern1.length;i++)
        {
            double currentValue = Math.abs(pattern1[i]-pattern2[i]);
            dist+= currentValue;
        }

        return dist;
    }
    protected static double calculateMahalanobisDistance(double[] linia1, double[] linia2, int numberOfPatterns)
    {
        double sum =0.0;
        for (int i=0;i<linia1.length; i++)
        {
            sum += Math.pow(linia1[i]-linia2[i],numberOfPatterns);

        }
       // sum= Math.pow(sum,numberOfPatterns);
        return Math.pow(sum,1.0/numberOfPatterns);
    }
    protected static double calculateCebisevDistance(double[] linia1, double[] linia2)
    {
        double distance =0.0;
        for (int i=0;i<linia1.length; i++)
        {
            double  currentDistance = Math.abs(linia1[i]-linia2[i]);
            distance = (currentDistance > distance )? currentDistance : distance;
        }
        return  distance;
    }
    protected static double calculateCityBlockDistance(double[] linia1, double[] linia2)
    {
        double sum =0.0;
        for (int i=0;i<linia1.length; i++)
        {
              sum += Math.abs(linia1[i]-linia2[i]);

        }
        return sum ;
    }

}
