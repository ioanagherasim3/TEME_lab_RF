package lab3;

import java.util.Arrays;
import java.util.Scanner;


public class MainClass {
    public static void main(String[] args) {
        String[][] learningSet;

        try {
            learningSet = FileUtils.readLearningSetFromFile("data.txt");
            FileUtils.writeLearningSetToFile("dataOUT.txt", learningSet);
            int numberOfPatterns = learningSet.length; //nr de coloane
            int numberOfFeatures = learningSet[0].length;// nr de linii
            System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
            System.out.println("..........................................");
            double []city = new double[] {25.89,47.56};
            double[] m = DistanceUtils.calculateEuclidianDistanceMatrice(learningSet,city);
            Arrays.sort(m);
            for(int i=0;i<learningSet.length;i++)
            {
                    System.out.println(m[i]+" "); // afiseaza toate distantele intre orasul nostru si celelalte
            }
            System.out.println("..........................................");
            System.out.println("Primele 9 orase sunt:");
            for(int i=0;i<9;i++)
            {

                System.out.println(m[i]+" ");

            }
           /* double[][] newPatterns = initNewPatterns();
            double[][] dist = new double[newPatterns.length][numberOfPatterns];
            for(int i=0;i< newPatterns.length;i++)
                for (int j = 0; j < numberOfPatterns; j++) {
                    dist[i][j] = DistanceUtils.EuclidianDistanceGEneralisedForm(newPatterns[i], Double.valueOf(learningSet[j]));
                }*/
            /*for( int i=1;i<numberOfPatterns;i++)
            {
            System.out.println(DistanceUtils.EuclidianDistanceGEneralisedForm (learningSet[0],learningSet[i]));
            }
            System.out.println("..........................................");
            System.out.println("Distanta Euclidean generalizata matrice");
            double [][] mat = new double [learningSet.length][learningSet.length];
            mat = DistanceUtils.EuclidianDistanceMatrix (learningSet);

            for(int i=0;i<learningSet.length;i++)
            {
                for(int j=0;j<learningSet.length;j++)
                {
                    System.out.print(mat[i][j] + "  ");
                }
                System.out.println();
            }*/
            System.out.println("..........................................");

           /* double [][]distanceMatrix = DistanceUtils.EuclidianDistanceMatrix(learningSet);
            int searchedPattern = numberOfPatterns-1;
            int closestPattern = 0;
            double []distanceRow= distanceMatrix[searchedPattern];
            double minDistance = distanceRow[0];
            for(int i=1; i<distanceRow.length;i++)
            {
                if(distanceRow[i]<minDistance && i!=searchedPattern)
                {
                    minDistance = distanceRow[i];
                    closestPattern= i;
                }
            }
            int classColumn = learningSet[closestPattern].length-1;
            System.out.println(String.format("Searched class %s",learningSet[closestPattern][classColumn]));
            System.out.println("..........................................");
            System.out.println(String.format("Euclidian distance:"));
            for( int i=1;i<numberOfPatterns;i++)
            {
                System.out.println( DistanceUtils.calculateEuclidianDistance(learningSet[0], learningSet[i]));
            }
            System.out.println("..........................................");
            System.out.println(String.format("Cebisev distance:"));
            for( int i=1;i<numberOfPatterns;i++)
            {
                System.out.println( DistanceUtils.calculateCebisevDistance(learningSet[0], learningSet[i]));
            }
            System.out.println("..........................................");
            System.out.println(String.format("City Block distance:"));
            for( int i=1;i<numberOfPatterns;i++)
            {
                System.out.println( DistanceUtils.calculateCityBlockDistance(learningSet[0], learningSet[i]));
            }
            System.out.println("..........................................");
            System.out.println(String.format("Mathalanobis distance:"));
            for( int i=1;i<numberOfPatterns;i++)
            {
                System.out.println( DistanceUtils.calculateMahalanobisDistance(learningSet[0], learningSet[i],numberOfPatterns ));
            }
            System.out.println("..........................................");*/
        } catch (USVInputFileCustomException er) {
            System.out.println(er.getMessage());
        } finally {
            System.out.println("Finished learning set operations");
        }
    }
    private static double [][] initNewPatterns(){
        double[][] newPatterns = new double [3][2];
        newPatterns[0][0] = 25.89;
        newPatterns[0][1] = 47.56;
        newPatterns[1][0] = 24;
        newPatterns[1][1] = 45.15;
        newPatterns[2][0] = 25.33;
        newPatterns[2][1] = 45.44;
        return newPatterns;
    }
}
