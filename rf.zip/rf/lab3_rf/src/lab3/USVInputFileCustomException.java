package lab3;

public class USVInputFileCustomException extends Exception{
    public USVInputFileCustomException(String messagee) {
        super(messagee);
    }

}
